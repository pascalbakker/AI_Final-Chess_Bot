SVG rendering
=============

This module renders SVGs (mostly for IPython integration). Pieces images
are copyright
`Colin M.L. Burnett <https://en.wikipedia.org/wiki/User:Cburnett>`_ and
licensed under GFDL & BSD & GPL.


.. autofunction:: chess.svg.piece

.. autofunction:: chess.svg.board
